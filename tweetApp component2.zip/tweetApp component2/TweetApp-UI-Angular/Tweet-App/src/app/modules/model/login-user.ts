export interface LoginUser {
    loginID:string;
    password:string;
}
