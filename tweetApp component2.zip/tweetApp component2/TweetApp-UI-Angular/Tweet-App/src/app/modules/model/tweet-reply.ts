export interface TweetReply {
  username: string;
  firstName: string;
  lastName: string;
  timeOfPost: string;
  reply: string;
  gender: string;
}
