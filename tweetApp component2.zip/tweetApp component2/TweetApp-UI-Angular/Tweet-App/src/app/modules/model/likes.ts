export interface Likes {
  count: number;
  likedBy: Array<string>;
}
