export interface TweetUser {
  loginID: string;
  firstName: string;
  lastName: string;
  gender: string;
}
