export interface ResetUser {
  loginID: string;

  password: string;
}
